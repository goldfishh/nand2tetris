import re
import sys
import os
class JackTokenizer:
	def __init__(self,file):
		fin = open(file,"r")
		self.contents = fin.read()
		#preprocessing
		self.fout_name = re.sub(r'\.jack',"T.xml",file)
		self.fout = open(self.fout_name,"w")
		# self.fout.write("<tokens>\n")
		self.contents = re.sub(r'\/\/[^\n]*',"",self.contents)
		self.contents = re.sub(r'\/\*\*[\d\D]*?\*\/',"",self.contents)
		# print (contents)
		self.symbol_Table = ["{","}","(",")","[","]",".",",",";","+","-","*","/","&","|","<",">","=","~"]
		self.keywords_Table = ["class","constructor","function","method","field","static","var","int","char","boolean","void","true","false","null","this","let","do","if","else","while","return"]
		for s in self.symbol_Table:
			self.contents = self.contents.replace(s," "+s+" ")
		# print (contents)
		# self.word_list = contents.split()  string have bug!
		self.word_list = re.findall(r'(\{|\}|\(|\)|\[|\]|\.|\,|\;|\+|\-|\*|\/|\&|\||\<|\>|\=|\~|\".*\"|\d+|[\w_]+)',self.contents)
		self.token_iter = 0
		self.now_token = ""
	def __del__(self):
		# self.fout.write("</tokens>")
		self.fout.close()
	def hasMoreTokens(self):
		if(self.token_iter < len(self.word_list)):
			return True
		else:
			return False
	def Advance(self):
		self.fout.write("<tokens>\n")
		while(self.hasMoreTokens()):
			self.now_token = self.word_list[self.token_iter]
			self.token_iter += 1;
			if(self.tokenType() == "KEYWORD"):
				tmp = self.keyword()
				self.fout.write(" <keyword> "+tmp+" </keyword>\n")
			elif(self.tokenType() == "SYMBOL"):
				tmp = self.symbol()
				self.fout.write(" <symbol> ")
				if(tmp == "<"):
					self.fout.write("&lt;")
				elif(tmp == ">"):
					self.fout.write("&gt;")
				elif(tmp == "\""):
					self.fout.write("&quot;")
				elif(tmp == "&"):
					self.fout.write("&amp;")
				else:
					self.fout.write(tmp)
				self.fout.write(" </symbol>\n")
			elif(self.tokenType() == "INT_CONST"):
				tmp = str(self.intVal())
				self.fout.write(" <integerConstant> "+tmp+" </integerConstant>\n")
			elif(self.tokenType() == "STRING_CONST"):
				tmp = self.stringVal()
				self.fout.write(" <stringConstant> "+tmp+" </stringConstant>\n")
			elif(self.tokenType() == "IDENTIFIER"):
				tmp = self.identifier()
				self.fout.write(" <identifier> "+tmp+" </identifier>\n")
		self.fout.write("</tokens>")
	def advance(self,Cfout):
		if(self.hasMoreTokens()):
			self.now_token = self.word_list[self.token_iter]
			self.token_iter += 1;
			if(self.tokenType() == "KEYWORD"):
				tmp = self.keyword()
				Cfout.write(" <keyword> "+tmp+" </keyword>\n")
			elif(self.tokenType() == "SYMBOL"):
				tmp = self.symbol()
				Cfout.write(" <symbol> ")
				if(tmp == "<"):
					Cfout.write("&lt;")
				elif(tmp == ">"):
					Cfout.write("&gt;")
				elif(tmp == "\""):
					Cfout.write("&quot;")
				elif(tmp == "&"):
					Cfout.write("&amp;")
				else:
					Cfout.write(tmp)
				Cfout.write(" </symbol>\n")
			elif(self.tokenType() == "INT_CONST"):
				tmp = str(self.intVal())
				Cfout.write(" <integerConstant> "+tmp+" </integerConstant>\n")
			elif(self.tokenType() == "STRING_CONST"):
				tmp = self.stringVal()
				Cfout.write(" <stringConstant> "+tmp+" </stringConstant>\n")
			elif(self.tokenType() == "IDENTIFIER"):
				tmp = self.identifier()
				Cfout.write(" <identifier> "+tmp+" </identifier>\n")
	def tokenType(self):
		for kw in self.keywords_Table:
			if(self.now_token == kw):
				return "KEYWORD"
		for sb in self.symbol_Table:
			if(self.now_token == sb):
				return "SYMBOL"
		if(self.now_token.isdigit()):
			return "INT_CONST"
		if(self.now_token[0] == '\"'):
			return "STRING_CONST"
		if(re.match(r'[_A-Za-z][\w_]*',self.now_token) != None):
			return "IDENTIFIER"
	def LL1tokenType(self):
		LL1token = self.word_list[self.token_iter]
		for kw in self.keywords_Table:
			if(LL1token == kw):
				return "KEYWORD"
		for sb in self.symbol_Table:
			if(LL1token == sb):
				return "SYMBOL"
		if(LL1token.isdigit()):
			return "INT_CONST"
		if(LL1token[0] == '\"'):
			return "STRING_CONST"
		if(re.match(r'[_A-Za-z][\w_]*',LL1token) != None):
			return "IDENTIFIER"				
	def keyword(self):
		for kw in self.keywords_Table:
			if(self.now_token == kw):
				return kw
	def symbol(self):
		for sb in self.symbol_Table:
			if(self.now_token == sb):
				return sb
	def identifier(self):
		return self.now_token
	def intVal(self):
		return self.now_token
	def stringVal(self):
		return self.now_token[1:len(self.now_token)-1]


class CompilationEngine:
	def __init__(self,obj):
		# self.fout_name = obj.fout_name
		self.fout_name = re.sub(r'T\.xml','.xml',obj.fout_name)
		self.fout = open(self.fout_name,"w")
		self.tokenizer = obj
		#self.num = -1
	def __del__(self):
		self.fout.close()
	def CompileClass(self):
		#self.num += 1
		self.fout.write("<class>\n")
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		while(self.tokenizer.word_list[self.tokenizer.token_iter] == 'static' or self.tokenizer.word_list[self.tokenizer.token_iter] == 'field' ):
			self.CompileClassVarDec()
		while(self.tokenizer.word_list[self.tokenizer.token_iter] == 'constructor' or self.tokenizer.word_list[self.tokenizer.token_iter] == 'function' or self.tokenizer.word_list[self.tokenizer.token_iter] == 'method' ):
			self.CompileSubroutine()	
		self.tokenizer.advance(self.fout)
		self.fout.write("</class>")	
	def CompileClassVarDec(self):
		self.fout.write("<classVarDec>\n")
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		while(self.tokenizer.word_list[self.tokenizer.token_iter] == ','):
			self.tokenizer.advance(self.fout)
			self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		self.fout.write("</classVarDec>\n")	
	def CompileSubroutine(self):
		self.fout.write("<subroutineDec>\n")	
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		self.tokenizer.advance(self.fout)
		self.CompileParameterList()
		self.tokenizer.advance(self.fout)
		self.CompileSubroutineBody()
		self.fout.write("</subroutineDec>\n")	
	def CompileSubroutineBody(self):
		self.fout.write("<subroutineBody>\n")
		self.tokenizer.advance(self.fout)  # {
		while(self.tokenizer.word_list[self.tokenizer.token_iter] == "var"):
			self.CompileVarDec()
		self.CompileStatements()
		self.tokenizer.advance(self.fout) # }
		self.fout.write("</subroutineBody>\n")	

	def CompileParameterList(self):
		self.fout.write("<parameterList>\n")
		if(self.tokenizer.word_list[self.tokenizer.token_iter] != ")"):
			self.tokenizer.advance(self.fout)  #type
			self.tokenizer.advance(self.fout)  #varName
			while(self.tokenizer.word_list[self.tokenizer.token_iter] == ","):
				 self.tokenizer.advance(self.fout)  #,
				 self.tokenizer.advance(self.fout)  #type
				 self.tokenizer.advance(self.fout)  #varName
		self.fout.write("</parameterList>\n")
	def CompileVarDec(self):
		self.fout.write("<varDec>\n")
		self.tokenizer.advance(self.fout)  #var
		self.tokenizer.advance(self.fout)  #type
		self.tokenizer.advance(self.fout)  #varName
		while(self.tokenizer.word_list[self.tokenizer.token_iter] == ","):
			self.tokenizer.advance(self.fout)  #,
			self.tokenizer.advance(self.fout)  #varName
		self.tokenizer.advance(self.fout)  #;
		self.fout.write("</varDec>\n")
	def CompileStatements(self):
		self.fout.write("<statements>\n")
		while(self.tokenizer.word_list[self.tokenizer.token_iter] == "let" or self.tokenizer.word_list[self.tokenizer.token_iter] == "if" or self.tokenizer.word_list[self.tokenizer.token_iter] == "while" or self.tokenizer.word_list[self.tokenizer.token_iter] == "do" or self.tokenizer.word_list[self.tokenizer.token_iter] == "return"):
			if(self.tokenizer.word_list[self.tokenizer.token_iter] == "let"):
				self.CompileLet()
			if(self.tokenizer.word_list[self.tokenizer.token_iter] == "if"):
				self.CompileIf()
			if(self.tokenizer.word_list[self.tokenizer.token_iter] == "return"):
				self.CompileReturn()
			if(self.tokenizer.word_list[self.tokenizer.token_iter] == "while"):
				self.CompileWhile()				
			if(self.tokenizer.word_list[self.tokenizer.token_iter] == "do"):
				self.CompileDo()
		self.fout.write("</statements>\n")		
	def CompileDo(self):
		self.fout.write("<doStatement>\n")
		self.tokenizer.advance(self.fout)  #'do'
		#subroutineCall
		self.tokenizer.advance(self.fout)  #subroutineName or className or varName
		if(self.tokenizer.word_list[self.tokenizer.token_iter] == "."):
			self.tokenizer.advance(self.fout)  # '.'
			self.tokenizer.advance(self.fout)  # subroutineName		
		self.tokenizer.advance(self.fout)  # '('
		self.CompileExpressionList()
		self.tokenizer.advance(self.fout)  # ')'
		self.tokenizer.advance(self.fout)  # ';'
		self.fout.write("</doStatement>\n")
	def CompileLet(self):
		self.fout.write("<letStatement>\n")
		self.tokenizer.advance(self.fout)  #'let'	
		self.tokenizer.advance(self.fout)  # varName
		if(self.tokenizer.word_list[self.tokenizer.token_iter] == "["):
			self.tokenizer.advance(self.fout)  # '['
			self.CompileExpression()
			self.tokenizer.advance(self.fout)  # ']'
		self.tokenizer.advance(self.fout)  # '='
		self.CompileExpression()
		self.tokenizer.advance(self.fout)  # ';'
		self.fout.write("</letStatement>\n")	
	def CompileWhile(self):
		self.fout.write("<whileStatement>\n")
		self.tokenizer.advance(self.fout)  #'while'	
		self.tokenizer.advance(self.fout)  # '('
		self.CompileExpression()
		self.tokenizer.advance(self.fout)  # ')'
		self.tokenizer.advance(self.fout)  # '{'
		self.CompileStatements()
		self.tokenizer.advance(self.fout)  # '}'		
		self.fout.write("</whileStatement>\n")	
	def CompileReturn(self):
		self.fout.write("<returnStatement>\n")
		self.tokenizer.advance(self.fout)  #'return'	
		if(self.tokenizer.word_list[self.tokenizer.token_iter] != ";"):
			self.CompileExpression()
		self.tokenizer.advance(self.fout)  # ';'
		self.fout.write("</returnStatement>\n")	
	def CompileIf(self):
		self.fout.write("<ifStatement>\n")
		self.tokenizer.advance(self.fout)  #'if'	
		self.tokenizer.advance(self.fout)  # '('
		self.CompileExpression()
		self.tokenizer.advance(self.fout)  # ')'
		self.tokenizer.advance(self.fout)  # '{'
		self.CompileStatements()
		self.tokenizer.advance(self.fout)  # '}'	
		if(self.tokenizer.word_list[self.tokenizer.token_iter] == "else"):
			self.tokenizer.advance(self.fout)  # "else"
			self.tokenizer.advance(self.fout)  # '{'
			self.CompileStatements()
			self.tokenizer.advance(self.fout)  # '}'						
		self.fout.write("</ifStatement>\n")	
	def CompileExpression(self):
		self.fout.write("<expression>\n")
		self.CompileTerm()
		if(self.tokenizer.word_list[self.tokenizer.token_iter] == "+" or self.tokenizer.word_list[self.tokenizer.token_iter] == "-" or self.tokenizer.word_list[self.tokenizer.token_iter] == "*" or self.tokenizer.word_list[self.tokenizer.token_iter] == "/" or self.tokenizer.word_list[self.tokenizer.token_iter] == "&" or self.tokenizer.word_list[self.tokenizer.token_iter] == "|" or self.tokenizer.word_list[self.tokenizer.token_iter] == "<" or self.tokenizer.word_list[self.tokenizer.token_iter] == ">" or self.tokenizer.word_list[self.tokenizer.token_iter] == "="):
			self.tokenizer.advance(self.fout)  # op
			self.CompileTerm()
		self.fout.write("</expression>\n")	
	def CompileTerm(self):
		self.fout.write("<term>\n")
		# self.tokenizer.now_token = self.tokenizer.word_list[self.tokenizer.token_iter]
		if(self.tokenizer.LL1tokenType() == "INT_CONST"):
			self.tokenizer.advance(self.fout) #INT
		elif(self.tokenizer.LL1tokenType() == "STRING_CONST"):
			self.tokenizer.advance(self.fout) #STRING
		elif(self.tokenizer.LL1tokenType() == "KEYWORD"):
			self.tokenizer.advance(self.fout)  # 'true' or 'false' or 'null' or 'this'
		elif(self.tokenizer.LL1tokenType() == "IDENTIFIER"):
			if(self.tokenizer.word_list[self.tokenizer.token_iter+1] == "+" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "-" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "*" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "/" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "&" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "|" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "<" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == ">" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "=" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "]" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == ")" or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "," or self.tokenizer.word_list[self.tokenizer.token_iter+1] == ";"):
				self.tokenizer.advance(self.fout)  # varName
			elif(self.tokenizer.word_list[self.tokenizer.token_iter+1] == "["):
				self.tokenizer.advance(self.fout)  # varName
				self.tokenizer.advance(self.fout)  # '['
				self.CompileExpression()
				self.tokenizer.advance(self.fout)  # ']'
			elif(self.tokenizer.word_list[self.tokenizer.token_iter+1] == "." or self.tokenizer.word_list[self.tokenizer.token_iter+1] == "("):
				if(self.tokenizer.word_list[self.tokenizer.token_iter+1] == "."):
					self.tokenizer.advance(self.fout)  # ClassName or varName
					self.tokenizer.advance(self.fout)  # '.'
				self.tokenizer.advance(self.fout)  # subroutineName
				self.tokenizer.advance(self.fout)  # '('
				self.CompileExpressionList()
				self.tokenizer.advance(self.fout)  # ')'
		elif(self.tokenizer.word_list[self.tokenizer.token_iter] == "("):
			self.tokenizer.advance(self.fout)  # '('
			self.CompileExpression()
			self.tokenizer.advance(self.fout)  # ')'			
		elif(self.tokenizer.word_list[self.tokenizer.token_iter] == "-" or self.tokenizer.word_list[self.tokenizer.token_iter] == "~"):
			self.tokenizer.advance(self.fout)  # unaryOp
			self.CompileTerm()	
		self.fout.write("</term>\n")	
	def CompileExpressionList(self):
		self.fout.write("<expressionList>\n")
		if(self.tokenizer.word_list[self.tokenizer.token_iter] != ")"):
			self.CompileExpression()
			while(self.tokenizer.word_list[self.tokenizer.token_iter] == ","):
				self.tokenizer.advance(self.fout)  #","
				self.CompileExpression()
		self.fout.write("</expressionList>\n")	

# class JackAnalyzer:
# 	def __init__():



#C:\Users\goldfish\Desktop\nand2tetris\tools\TextComparer.bat
if (__name__ == '__main__'):
	print(len(sys.argv))
	for i in range(len(sys.argv)):
		if(i == 0):
			continue
		tmp = sys.argv[i]
		print(tmp)
		_path = ""
		if(tmp.find(".") == -1):
			if(tmp[0] != '/'):
				_path = os.getcwd() + "/"
				_path = os.path.join(_path,tmp)
				os.chdir(_path)
			else:
				_path = tmp
				os.chdir(_path)
			for fpath,dirs,fs in os.walk(_path):
				for file in fs:
					if(file.find(".jack") != -1):
						obj1 = JackTokenizer(file)
						obj1.Advance()
						obj2 = JackTokenizer(file)					
						compiler = CompilationEngine(obj2)
						compiler.CompileClass()
		else:
			obj1 = JackTokenizer(tmp)
			obj1.Advance()
			obj2 = JackTokenizer(tmp)		
			compiler = CompilationEngine(obj2)
			compiler.CompileClass()
			# obj = JackTokenizer("C:\\Users\\goldfish\\Desktop\\nand2tetris\\projects\\10\\ArrayTest\\Main.jack")


	